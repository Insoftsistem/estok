        <!-- 
        expose component model to current view
        e.g $arrDataFromDb = $comp_model->fetchData(); //function name
        -->
        <?php $comp_model = app('App\Models\ComponentsData'); ?>
        <?php 
            $pageTitle = __('estok'); // set page title
        ?>
        
        <?php $__env->startSection('title', $pageTitle); ?>
        <?php $__env->startSection('content'); ?>
        <div>
            <div  class="mb-3" >
                <div class="container-fluid">
                    <div class="row justify-content-start">
                        <div class="col col-sm-6 col-md-3 col-lg-3 comp-grid " >
                            <div class=" card-7 mt-5 bg-light"><div class="h4 fw-bold text-primary text-center">
                                <img src="<?php echo e(asset('images/logo.png')); ?>" width="50px" height="50px" class="img-fluid rounded-circle" /> 
                                <?php echo e(__('userLogin')); ?>

                            </div>
                        </div>
                        <div  class="card card-7 page-content" >
                            
                            <div>
                                <?php if($errors->any()): ?>
                                <div class="alert alert-danger animated bounce"><?php echo e($errors->first()); ?></div>
                                <?php endif; ?>
                                <form name="loginForm" action="<?php echo e(route('auth.login')); ?>" class="needs-validation form page-form" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="input-group form-group">
                                        <input placeholder="<?php echo e(__('usernameOrEmail')); ?>" name="username"  required="required" class="form-control" type="text"  />
                                        <span class="input-group-text"><i class="form-control-feedback material-icons">account_circle</i></span>
                                    </div>
                                    <div class="input-group form-group">
                                        
                                        <input  placeholder="<?php echo e(__('password')); ?>" required="required" name="password" class="form-control " type="password" />
                                        <span class="input-group-text"><i class="form-control-feedback material-icons">lock</i></span>
                                    </div>
                                    <div class="row clearfix mt-3 mb-3">
                                        <div class="col-6">
                                            <label class="">
                                            <input value="true" type="checkbox" name="rememberme" />
                                            <?php echo e(__('rememberMe')); ?>

                                            </label>
                                        </div>
                                        <div class="col-6">
                                            <a href="<?php echo e(route('password.forgotpassword')); ?>" class="text-danger"> <?php echo e(__('resetPassword')); ?></a>
                                        </div>
                                    </div>
                                    <div class="form-group text-center">
                                        <button class="btn btn-primary btn-block btn-md" type="submit"> 
                                        <i class="load-indicator">
                                        <clip-loader :loading="loading" color="#fff" size="20px"></clip-loader> 
                                        </i>
                                        <?php echo e(__('login')); ?> <i class="material-icons">lock_open</i>
                                        </button>
                                    </div>
                                </form>
                            </div>
                            
                        </div>
                        <div class=" card-7">                                   <div class="text-center">
                            <?php echo e(__('dontHaveAnAccount')); ?> <a href="<?php echo e(route('auth.register')); ?>" class="btn btn-success"><?php echo e(__('register')); ?>

                            <i class="material-icons">account_box</i></a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 comp-grid " >
                    <div class=" "><div>
                        <style>
                        body { font-family: Arial, sans-serif; background: #f4f4f4; margin:0; padding:0; }
                        .site-config { max-width: 800px; margin:50px auto; background:#fff; padding:30px; border-radius:10px; box-shadow:0 4px 12px rgba(0,0,0,0.1); }
                        .logo img { max-width:150px; margin-bottom:20px; }
                        h1 { margin:0 0 10px; font-size:28px; color:#333; }
                        p { margin:5px 0; color:#555; }
                        .redes-sociais { margin-top:20px; }
                        .redes-sociais a { display:inline-block; margin-right:15px; font-size:24px; color:#555; transition: color 0.3s; text-decoration:none; }
                        .redes-sociais a:hover { color:#007BFF; }
                        .info { margin-top:15px; }
                        </style>
                        </head>
                        <body>
                        <?php if($data): ?>
                        <div class="site-config">
                            <div class="logo">
                                <?php if(!empty($data->logo)): ?>
                                <img src="<?php echo e(asset($data->logo)); ?>" alt="Logo do Site">
                                <?php endif; ?>
                            </div>
                            <h1><?php echo e($data->nome_site); ?></h1>
                            <div class="info">
                                <?php if($data->cnpj): ?>
                                <p><strong>CNPJ:</strong> <?php echo e($data->cnpj); ?></p>
                                <?php endif; ?>
                                <?php if($data->endereco): ?>
                                <p><strong>Endereço:</strong> <?php echo $data->endereco; ?></p>
                                <?php endif; ?>
                                <?php if($data->telefone): ?>
                                <p><strong>Telefone:</strong> <?php echo e($data->telefone); ?></p>
                                <?php endif; ?>
                                <?php if($data->whatsapp): ?>
                                <p><strong>WhatsApp:</strong> <?php echo e($data->whatsapp); ?></p>
                                <?php endif; ?>
                                <?php if($data->email): ?>
                                <p><strong>Email:</strong> <?php echo e($data->email); ?></p>
                                <?php endif; ?>
                                <?php if($data->horario_funcionamento): ?>
                                <p><strong>Horário de Funcionamento:</strong> <?php echo $data->horario_funcionamento; ?></p>
                                <?php endif; ?>
                            </div>
                            <div class="redes-sociais">
                                <?php if($data->facebook): ?>
                                <a href="https://facebook.com/<?php echo e($data->facebook); ?>" target="_blank">
                                    <i class="fab fa-facebook"></i>
                                </a>
                                <?php endif; ?>
                                <?php if($data->instagram): ?>
                                <a href="https://instagram.com/<?php echo e($data->instagram); ?>" target="_blank">
                                    <i class="fab fa-instagram"></i>
                                </a>
                                <?php endif; ?>
                                <?php if($data->twitter): ?>
                                <a href="https://twitter.com/<?php echo e($data->twitter); ?>" target="_blank">
                                    <i class="fab fa-twitter"></i>
                                </a>
                                <?php endif; ?>
                                <?php if($data->linkedin): ?>
                                <a href="https://linkedin.com/in/<?php echo e($data->linkedin); ?>" target="_blank">
                                    <i class="fab fa-linkedin"></i>
                                </a>
                                <?php endif; ?>
                                <?php if($data->youtube): ?>
                                <a href="https://youtube.com/<?php echo e($data->youtube); ?>" target="_blank">
                                    <i class="fab fa-youtube"></i>
                                </a>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php else: ?>
                        <p style="text-align:center; margin-top:50px;">
                        Nenhuma configuração cadastrada.
                        </p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div  class="mb-3" >
    <div class="container-fluid">
        <div class="row ">
            <div class="col comp-grid " >
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<!-- Page custom css -->
<?php $__env->startSection('pagecss'); ?>
<style>
<style></style>
</style>
<?php $__env->stopSection(); ?>
<!-- Page custom js -->
<?php $__env->startSection('pagejs'); ?>
<script>
    $(document).ready(function(){
    // custom javascript | jquery codes
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\estok\resources\views/pages/index/index.blade.php ENDPATH**/ ?>