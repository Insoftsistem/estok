# Getting Started with estok

### Generated with [RadSystems](https://radsystems.io)

## Frameworks

- ### UI Framework - [Laravel](https://laravel.com)

- ### Database ORM - [Eloquent ORM](https://laravel.com/docs/5.0/eloquent)
- ### Default Database - [MySQL](https://www.mysql.com/)
