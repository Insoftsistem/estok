
<?php 
	return [
		'fr' => 'French',
'ru' => 'Russian',
'zh-CN' => 'Chinese',
'en-US' => 'English',
'it' => 'Italian',
'hi' => 'Hindi',
'pt' => 'Portuguese',
'de' => 'German',
'es' => 'Spanish',
'ar' => 'Arabic'
	];
