@extends('layouts.info')
@section('content')
<div class="container my-4">
	<h4>Help And Frequently Asked Questions</h4>
	<hr />
	<div>
		<p>Put page content here.</p>
		
		@php
    $records = DB::table('info')->get();
@endphp

@foreach($records as $data)

    
        <h2>Sobre Nós</h2>
        {!!$data->faq!!}
    

   
@endforeach
	</div>
</div>
@endsection